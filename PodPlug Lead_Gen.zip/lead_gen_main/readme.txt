!!! Make sure you've EXTRACTED the file. It comes compressed. Otherwise, there may be unexpected problems !!!

!!! Also, make sure you are using a VPN. This program uses webscraping to get detailed info, and Yelp may flag your IP if you don't use a VPN. !!!



Step 1: Create a folder on your desktop. You can name it anything.

Step 2: Copy the path of the folder into path.txt (it's in the main directory of lead_gen).

Step 3: Find categories that you will want to scrape from in the cat_list pdf. Make sure to use Yelp's category parameter EXACTLY. If you do not enter a category, it will grab EVERYTHING.
	
	For examples, on the pdf you will see :
	
	• Beach Equipment Rentals (beachequipmentrental, All)
		^^^^^^^		        ^^^^^^^^^^^      ^^^
	Vernacular category	   Category Parameter   Inclusivity (not relavent)

	So... you're going to use beachequipmentrental NOT Beach Equipment Rentals



	If you're using multiple categories, you seperate them with a comma, and NO spaces

	
	Example: beachequipmentrental,bars,nightclubs




